
# tests/test_physical_correction.py
from dual_clocking_qubit import DualClockingConfig, build_schedule, run_simulator

def test_physical_path_records_event():
    cfg = DualClockingConfig(seed=3, two_tone=True, probe_threshold=0.5, physical_correction=True)
    res = run_simulator(cfg, build_schedule(cfg))
    assert any(ev.get("where")=="physical" for ev in res.feed_forward_events)
