
# examples/cli.py
import argparse
from dual_clocking_qubit import DualClockingConfig, build_schedule, run_simulator

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--two-tone", action="store_true")
    p.add_argument("--physical", action="store_true", help="Use physical correction instead of virtual")
    p.add_argument("--probe-threshold", type=float, default=0.0)
    args = p.parse_args()

    cfg = DualClockingConfig(seed=args.seed, two_tone=args.two_tone,
                             physical_correction=args.physical,
                             probe_threshold=args.probe_threshold)
    sched = build_schedule(cfg)
    res = run_simulator(cfg, sched)
    print("Final state:", tuple(round(v,4) for v in res.final_state))
    print("Probe outcome:", res.probe_outcome)
    print("Feed-forward events:", res.feed_forward_events)

if __name__ == "__main__":
    main()
