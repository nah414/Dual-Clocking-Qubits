
# Feed‑Forward: Virtual vs Physical (and SQI Gate)

**Virtual correction** updates the software **phase frame** (a Z‑rotation bookkeeping) with no physical pulse.
**Physical correction** applies an actual pulse (e.g., small `RX(+0.15π)`) to steer the Bloch vector.

- Use **virtual** when pulse budgets are tight or crosstalk risk is high.
- Use **physical** when you must reset into a known region before the second drive for tighter control.

## SQI Pre‑Flight Gate (required in our topological mode)
We require `edge_fraction ≥ 0.70` before enabling the program:
```python
from dual_clocking_qubit import require_sqi_edge_fraction
require_sqi_edge_fraction(edge_fraction, min_required=0.70)
```
If the device is not in Regime‑A (edge‑dominated), abort early to avoid misleading signatures.
