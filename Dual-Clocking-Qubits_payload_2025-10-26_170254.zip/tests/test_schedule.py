
# tests/test_schedule.py
from dual_clocking_qubit import DualClockingConfig, build_schedule, run_simulator

def test_minimal_runs():
    cfg = DualClockingConfig(seed=1)
    sched = build_schedule(cfg)
    res = run_simulator(cfg, sched)
    assert isinstance(res.probe_outcome, int)
