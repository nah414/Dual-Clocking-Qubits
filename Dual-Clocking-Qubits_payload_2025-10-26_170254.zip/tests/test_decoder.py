
# tests/test_decoder.py
from dual_clocking_qubit import decode_majority

def test_decode_majority():
    assert decode_majority([1,1,0]) == 1
    assert decode_majority([0,0,1]) == 0
