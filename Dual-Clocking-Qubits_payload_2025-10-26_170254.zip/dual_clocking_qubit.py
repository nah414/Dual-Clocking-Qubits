
# dual_clocking_qubit.py
# -*- coding: utf-8 -*-
"""
Dual-Clocking Qubit Operations — Drive–Probe–Drive (with optional two-tone),
mid-circuit measurement, virtual-vs-physical corrections, decoding hook,
and a compact Lindblad-like simulator.
Version: v0.4 (2025-10-26 America/Chicago)
Authors: Adam × Nova

This is a simplified, self-contained reference useful for unit tests and examples.
It does NOT depend on external quantum SDKs; it's a light simulator suitable for CI.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Tuple, Optional
import math
import random

@dataclass
class DualClockingConfig:
    seed: int = 7
    t_drive_1: float = 20.0   # ns
    t_probe: float = 8.0      # ns
    t_drive_2: float = 20.0   # ns
    omega: float = 1.0        # arbitrary units
    gamma_deph: float = 0.01  # dephasing (arb.)
    two_tone: bool = False
    probe_threshold: float = 0.0  # compare σ_z estimate against this
    physical_correction: bool = False  # if False => virtual-Z only

@dataclass
class StepEvent:
    name: str
    t_ns: float
    meta: Dict = field(default_factory=dict)

@dataclass
class Schedule:
    steps: List[StepEvent] = field(default_factory=list)

    def add(self, name: str, t_ns: float, **meta):
        self.steps.append(StepEvent(name=name, t_ns=t_ns, meta=meta))

def build_schedule(cfg: DualClockingConfig) -> Schedule:
    s = Schedule()
    s.add("drive_1", cfg.t_drive_1, omega=cfg.omega, two_tone=cfg.two_tone)
    s.add("probe",   cfg.t_probe,   threshold=cfg.probe_threshold)
    s.add("drive_2", cfg.t_drive_2, omega=cfg.omega, two_tone=cfg.two_tone)
    return s

# Simple qubit state as Bloch vector (x,y,z). Length <= 1 due to dephasing.
Bloch = Tuple[float, float, float]

def _rz(state: Bloch, theta: float) -> Bloch:
    x,y,z = state
    c, s = math.cos(theta), math.sin(theta)
    return (x*c - y*s, x*s + y*c, z)

def _rx(state: Bloch, theta: float) -> Bloch:
    x,y,z = state
    c, s = math.cos(theta), math.sin(theta)
    return (x, y*c - z*s, y*s + z*c)

def _dephase(state: Bloch, gamma: float) -> Bloch:
    x,y,z = state
    k = max(0.0, 1.0 - gamma)
    return (x*k, y*k, z)

def _measure_z(state: Bloch, rng: random.Random) -> Tuple[int, Bloch, float]:
    # Projective measurement in Z with classical outcome; return (m, post_state, est_z)
    x,y,z = state
    p1 = (1.0 + z) * 0.5
    m = 1 if rng.random() < p1 else 0
    post = (0.0, 0.0, 1.0 if m==1 else -1.0)
    est = z  # crude estimator
    return m, post, est

@dataclass
class SimResult:
    final_state: Bloch
    probe_outcome: int
    est_z_at_probe: float
    feed_forward_events: List[Dict]

def run_simulator(cfg: DualClockingConfig, schedule: Schedule) -> SimResult:
    rng = random.Random(cfg.seed)
    state: Bloch = (0.0, 0.0, 1.0)   # |0> (z=+1)

    feed_events: List[Dict] = []

    for step in schedule.steps:
        if step.name == "drive_1":
            theta = step.meta.get("omega", 1.0) * step.t_ns * 0.01
            if step.meta.get("two_tone", False):
                state = _rz(state, 0.25*theta)
                state = _rx(state, theta)
                state = _rz(state, -0.15*theta)
            else:
                state = _rx(state, theta)
            state = _dephase(state, cfg.gamma_deph)

        elif step.name == "probe":
            m, post, est = _measure_z(state, rng)
            state = post
            # virtual vs physical correction
            if est < step.meta.get("threshold", 0.0):
                if cfg.physical_correction:
                    # apply an actual rotation to steer back toward +Z
                    state = _rx(state, +0.15*math.pi)
                    feed_events.append({"where": "physical", "theta": +0.15*math.pi})
                else:
                    # virtual Z-frame update (record-only)
                    feed_events.append({"where": "virtual", "phi": +0.1*math.pi})
            probe_outcome = m
            est_at_probe = est

        elif step.name == "drive_2":
            theta = step.meta.get("omega", 1.0) * step.t_ns * 0.01
            if step.meta.get("two_tone", False):
                state = _rz(state, 0.1*theta)
                state = _rx(state, theta*0.9)
                state = _rz(state, +0.05*theta)
            else:
                state = _rx(state, theta)
            state = _dephase(state, cfg.gamma_deph)

    return SimResult(final_state=state,
                     probe_outcome=probe_outcome,
                     est_z_at_probe=est_at_probe,
                     feed_forward_events=feed_events)

# Optional gate to enforce SQI precheck (placeholder threshold mechanism)
def require_sqi_edge_fraction(edge_fraction: float, min_required: float = 0.7):
    if edge_fraction < min_required:
        raise ValueError(f"SQI edge_fraction {edge_fraction:.2f} < required {min_required:.2f}")

# Decoding hook: convert repeated shots to a logical estimate (simple majority vote here)
def decode_majority(measurements: List[int]) -> int:
    ones = sum(measurements)
    zeros = len(measurements) - ones
    return 1 if ones >= zeros else 0
