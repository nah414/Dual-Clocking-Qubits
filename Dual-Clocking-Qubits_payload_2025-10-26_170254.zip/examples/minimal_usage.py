
# examples/minimal_usage.py
from dual_clocking_qubit import DualClockingConfig, build_schedule, run_simulator

if __name__ == "__main__":
    cfg = DualClockingConfig(seed=42, two_tone=False)
    sched = build_schedule(cfg)
    res = run_simulator(cfg, sched)
    print("Final state (x,y,z):", res.final_state)
    print("Probe outcome:", res.probe_outcome)
    print("Feed-forward events:", res.feed_forward_events)
