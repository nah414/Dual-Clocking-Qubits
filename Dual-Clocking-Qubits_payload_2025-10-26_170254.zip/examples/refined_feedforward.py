
# examples/refined_feedforward.py
from dual_clocking_qubit import DualClockingConfig, build_schedule, run_simulator

if __name__ == "__main__":
    cfg = DualClockingConfig(seed=123, two_tone=True, probe_threshold=0.0, physical_correction=False)
    sched = build_schedule(cfg)
    res = run_simulator(cfg, sched)
    print("Estimated z at probe:", round(res.est_z_at_probe, 4))
    print("Probe outcome:", res.probe_outcome)
    print("Feed-forward events:", res.feed_forward_events)
