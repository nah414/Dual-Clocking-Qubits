
# Dual-Clocking Qubits (payload)
Minimal, CI-ready implementation of the drive–probe–drive control loop with virtual/physical feed-forward and a toy decoder.

## Quickstart (Windows, Python 3.12)
```powershell
python -m venv .venv
. .venv/Scripts/Activate.ps1
pip install -r requirements.txt  # optional; not needed here
pytest -q
python examples/minimal_usage.py
```

## Files
- `dual_clocking_qubit.py` — core module
- `examples/*.py` — runnable examples
- `tests/*` — smoke tests
- `.github/workflows/ci.yml` — CI
