# Dual-Clocking — Quickstart Environment

Run the dual-clocking scheduler with either **Superconducting** or **Trapped-Ion** backends.

## Local quickstart

```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -U pip
pip install -e .[dev]
python scripts/demo_sc.py     # superconducting demo
python scripts/demo_ion.py    # trapped-ion demo
pytest -q
```

## Codespaces / Dev Container

Open this folder in GitHub **Codespaces** or VS Code **Dev Containers**. It will auto-install deps.
Then run:
```bash
python scripts/demo_sc.py
python scripts/demo_ion.py
pytest -q
```

## CLI

```bash
python main.py --backend ion --t-wait 1e-5 --strength 0.2
python main.py --backend sc  --t-wait 2e-7 --strength 0.2
```
