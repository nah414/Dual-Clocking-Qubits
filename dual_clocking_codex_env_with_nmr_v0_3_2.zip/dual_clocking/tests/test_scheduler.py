from dual_clocking.backends import SuperconductingBackend, TrappedIonBackend
from dual_clocking.scheduler import DualClockScheduler, DrivePulse, ProbePulse, Barrier

def test_run_sc_backend():
    be = SuperconductingBackend()
    be.calibrate(0)
    sch = DualClockScheduler(be)
    sch.add(DrivePulse(qubit=0, duration=20e-9, amp=0.5))
    sch.add(ProbePulse(qubit=0, duration=200e-9, strength=0.2))
    sch.add(Barrier())
    res = sch.run()
    assert len(res) == 1

def test_run_ion_backend():
    be = TrappedIonBackend()
    be.calibrate(0)
    sch = DualClockScheduler(be)
    sch.add(DrivePulse(qubit=0, duration=0.6e-6, amp=0.5))
    sch.add(ProbePulse(qubit=0, duration=10e-6, strength=0.2))
    res = sch.run()
    assert len(res) == 1
