from __future__ import annotations

from ..scheduler import DualClockScheduler, DrivePulse, ProbePulse, Barrier
from ..backends import Backend

def dc_ramsey(backend: Backend, qubit: int, t_wait: float, drive_amp: float = 0.5, probe_strength: float = 0.2):
    sch = DualClockScheduler(backend)
    sch.add(DrivePulse(qubit=qubit, duration=2/3 * 1e-6 if backend.name=="trapped_ion" else 20e-9, amp=drive_amp, phase=0.0))
    sch.add(Barrier())
    sch.add(ProbePulse(qubit=qubit, duration=t_wait, strength=probe_strength, detuning=0.0, weak=True))
    sch.add(Barrier())
    sch.add(DrivePulse(qubit=qubit, duration=2/3 * 1e-6 if backend.name=="trapped_ion" else 20e-9, amp=drive_amp, phase=0.0))
    return sch.run()
