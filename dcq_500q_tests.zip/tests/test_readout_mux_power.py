from dcq.readout import total_power_dbm

def test_power_sum_dbm():
    tones = [-90.0]*8  # 8:1 mux at -90 dBm each (example)
    total = total_power_dbm(tones)
    # The sum should be ~ -81 dBm (10*log10(8) ≈ 9 dB higher than one tone)
    assert -82.0 < total < -80.0
