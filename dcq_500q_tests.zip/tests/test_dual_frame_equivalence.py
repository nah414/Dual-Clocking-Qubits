from dcq.frames import x90_frame_equivalence

def test_x90_equivalent_across_frames():
    # Two different Z phases should still yield equivalent X/2 up to phase
    d = x90_frame_equivalence(phase1=0.0, phase2=1.234)
    assert d < 1e-6
