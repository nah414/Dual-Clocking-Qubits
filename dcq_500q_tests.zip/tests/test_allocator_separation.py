from dcq.allocator import allocate_frequencies

def test_neighbor_separation():
    # line graph 0-1-2-3
    graph = {0:[1],1:[0,2],2:[1,3],3:[2]}
    plan = allocate_frequencies(graph, base=5.0e9, step=12.5e6)
    assert abs(plan[0] - plan[1]) >= 12.5e6
    assert abs(plan[1] - plan[2]) >= 12.5e6
    assert abs(plan[2] - plan[3]) >= 12.5e6
