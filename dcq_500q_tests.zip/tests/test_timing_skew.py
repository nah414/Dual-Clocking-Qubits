from dcq.timing import residual_skew_ps

def test_skew_peak_to_peak():
    cal = {"ch0": 10, "ch1": 42, "ch2": 5}
    assert residual_skew_ps(cal) == 37
