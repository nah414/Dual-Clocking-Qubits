from __future__ import annotations
import hashlib
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple

@dataclass(frozen=True)
class Event:
    t: int  # integer samples
    chan: str
    op: str
    args: Tuple[Any, ...]

def canonical_hash(events: List[Event]) -> str:
    """Deterministic hash of an event table."""
    # sort by (t, chan, op, args) to ensure determinism for equal schedules
    ordered = sorted(events, key=lambda e: (e.t, e.chan, e.op, e.args))
    buf = "".join(f"{e.t}|{e.chan}|{e.op}|{e.args}\n" for e in ordered).encode()
    return hashlib.sha256(buf).hexdigest()

def build_schedule(reqs: List[Dict[str, Any]], resources: Dict[str, int]) -> List[Event]:
    """
    Toy scheduler: packs operations on channels with simple resource guards.
    Ensures integer-sample timing. Deterministic given same inputs.
    """
    time_cursor = 0
    events: List[Event] = []
    for r in reqs:
        # simple resource gating by island occupancy
        island = r.get("island", "I0")
        if resources.get(island, 0) <= 0:
            raise ValueError(f"No capacity for island {island}")
        dur = int(r.get("dur_samples", 16))
        chan = r["chan"]
        op = r["op"]
        args = tuple(r.get("args", ()))
        events.append(Event(t=time_cursor, chan=chan, op=op, args=args))
        time_cursor += dur
    return events
