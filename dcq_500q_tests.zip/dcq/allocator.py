from __future__ import annotations
from typing import Dict, List, Tuple, Set
import random

def allocate_frequencies(graph: Dict[int, List[int]], 
                         base: float = 5.0e9, step: float = 12.5e6) -> Dict[int, float]:
    """
    Very simple graph-coloring-inspired allocator:
    assigns frequencies separated by >= step for neighbors.
    """
    order = sorted(graph.keys(), key=lambda n: -len(graph[n]))
    assigned: Dict[int, float] = {}
    used: Set[float] = set()
    for node in order:
        neighbor_freqs = {assigned[n] for n in graph[node] if n in assigned}
        f = base
        # bump until we find a gap relative to neighbors
        while any(abs(f - nf) < step for nf in neighbor_freqs):
            f += step
        assigned[node] = f
        used.add(f)
    return assigned
